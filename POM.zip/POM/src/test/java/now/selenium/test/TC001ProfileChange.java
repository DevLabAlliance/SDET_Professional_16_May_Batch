package now.selenium.test;

import org.testng.annotations.Test;

import now.selenium.base.ProjectSpecific;
import now.selenium.servicenowPages.DashBoardPage;
import now.selenium.servicenowPages.LoginPage;


// Points to remember
//0. Create seperate classes for every pages
//1. Extend all your classes to the base class
//2. Write all the elements or function in a method
//3. return where the next function or the page(class) is leading to
//4. extend the base class to all your test scripts


public class TC001ProfileChange extends ProjectSpecific{
	
	@Test
	public void profile() {
		// login
		
		/*
		 * LoginPage login = new LoginPage();
		 * login.enterUserName("admin");
		 * login.enterPassword("Pass"); 
		 * login.clickLogin();
		 */
		
		new LoginPage()
		.enterUserName("admin")
		.enterPassword("Pass123$")
		.clickLogin();
		
		new DashBoardPage()
		.clickUserMenu()
		.clickLogOut();
		
	}

}
