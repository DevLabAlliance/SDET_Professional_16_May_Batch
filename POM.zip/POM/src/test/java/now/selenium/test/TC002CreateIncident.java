package now.selenium.test;

import org.testng.annotations.Test;

import now.selenium.servicenowPages.LoginPage;

public class TC002CreateIncident {
	
	@Test
	public void profile() {
		// login
		
		LoginPage login = new  LoginPage();
		login.enterUserName("admin");
		login.enterPassword("Pass");
		login.clickLogin();
		
		
		// steps to create an incident
		
		
		
		// a'dl,as
	}

}
