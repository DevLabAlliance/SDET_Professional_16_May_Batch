package learnStatic;

public class LearnStatic {

	
	 
	static int  a = 0;
	int b =0;
	
	void getCounter() {
		a++;
		b++;
		System.out.println("static "+a + " ---> non static "+b);
	}
	public static void main(String[] args) {
		LearnStatic ls = new LearnStatic();
		ls.getCounter();
		ls.getCounter();
		ls.getCounter();
		System.out.println("---------");
		LearnStatic ls1 = new LearnStatic();
		ls1.getCounter();
		ls1.getCounter();
		ls1.getCounter();
		ls1.getCounter();
		System.out.println("---------");
		LearnStatic ls3 = new LearnStatic();
		ls3.getCounter();
		ls3.getCounter();
		
		
		/*
		 * String name = "koushik"; System.out.println(name.concat(" c"));
		 * System.out.println(name);
		 * 
		 * StringBuffer sb = new StringBuffer("kosuhik");
		 * System.out.println(sb.append(" chatterjee")); System.out.println(sb);
		 */
		
		
		
		
		
		
	}
	
}
