package now.selenium.servicenowPages;

public class ProfilePage {

}
