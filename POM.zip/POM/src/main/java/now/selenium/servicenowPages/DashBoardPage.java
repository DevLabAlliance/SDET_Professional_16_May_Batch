package now.selenium.servicenowPages;

import now.selenium.base.ProjectSpecific;

public class DashBoardPage extends ProjectSpecific {
	// note: common page
	
	public DashBoardPage enterOnFilter(String filterData){
		return this;
		// 
	}
	public CreateIncidentPage clickCreateNewIncident() {
		
		return new CreateIncidentPage();
		
	}
	public DashBoardPage clickUserMenu() {
		driver.findElementByCssSelector("#user_info_dropdown").click();
		return this;
	}
	public void clickLogOut(){
		driver.findElementByLinkText("Logout").click();
	}
}




