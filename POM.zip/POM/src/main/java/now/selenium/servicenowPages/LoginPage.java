package now.selenium.servicenowPages;

import org.openqa.selenium.WebElement;

import now.selenium.base.ProjectSpecific;

public class LoginPage extends ProjectSpecific {

	public LoginPage enterUserName(String username){
		driver.switchTo().frame(0);
		WebElement userNameEle = findElementBy("id", "user_name");
		clearAndType(userNameEle, username);
		return this;
	}
	
	public LoginPage enterPassword(String pwd) {
		driver.findElementById("user_password").sendKeys(pwd);
		return this;
	}
	
	public DashBoardPage clickLogin() {
		click(findElementBy("id", "sysverb_login"));
		return new DashBoardPage();
	}

}
