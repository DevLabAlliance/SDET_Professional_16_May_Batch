package now.selenium.servicenowPages;

public class CreateIncidentPage {

}
