package now.selenium.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class ProjectSpecific extends ServiceNowBase{
//	protected static ChromeDriver driver;

	@BeforeMethod
	public void launchApp() {
		startApp("https://dev60491.service-now.com/navpage.do");
	}

	@AfterMethod
	public void stopApp() {
		driver.quit();
	}

}



