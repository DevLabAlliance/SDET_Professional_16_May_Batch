package now.selenium.base;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ServiceNowBase implements Browser, Element{


	protected static RemoteWebDriver driver;

	public void click(WebElement ele) {
		try {
			ele.click();
			System.out.println("The element has click successfully ");
		} catch (Exception e) {
		System.err.println("some ");
		}
	}

	public void append(WebElement ele, String data) {
		// TODO Auto-generated method stub

	}

	public void clear(WebElement ele) {
		// TODO Auto-generated method stub

	}

	public void clearAndType(WebElement ele, String data) {
		try {
			ele.clear();
			ele.sendKeys(data);
			System.out.println(data+ " is entered");
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
//			driver.getScreenshotAs(Ou)
		}
	}

	public String getElementText(WebElement ele) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getBackgroundColor(WebElement ele) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getTypedText(WebElement ele) {
		// TODO Auto-generated method stub
		return null;
	}

	public void selectDropDownUsingText(WebElement ele, String value) {
		// TODO Auto-generated method stub

	}

	public void selectDropDownUsingIndex(WebElement ele, int index) {
		// TODO Auto-generated method stub

	}

	public void selectDropDownUsingValue(WebElement ele, String value) {
		// TODO Auto-generated method stub

	}

	public boolean verifyExactText(WebElement ele, String expectedText) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyPartialText(WebElement ele, String expectedText) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyExactAttribute(WebElement ele, String attribute, String value) {
		// TODO Auto-generated method stub
		return false;
	}

	public void verifyPartialAttribute(WebElement ele, String attribute, String value) {
		// TODO Auto-generated method stub

	}

	public boolean verifyDisplayed(WebElement ele) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyDisappeared(WebElement ele) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyEnabled(WebElement ele) {
		// TODO Auto-generated method stub
		return false;
	}

	public void verifySelected(WebElement ele) {
		// TODO Auto-generated method stub

	}

	public void startApp(String url) {
		try {
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get(url);
			System.out.println("The browser has been launched");
		} catch (Exception e) {
			System.err.println("Browser could not launch "+e.getMessage());
		}
	}

	public void startApp(String browser, String url) {
		// TODO Auto-generated method stub

	}

	public WebElement findElementBy(String locatorType, String value) {
		try {
			switch (locatorType) {
			case "id":
				return driver.findElement(By.id(value));
			case "name":
				return	driver.findElement(By.name(value));

			default:
				System.err.println("Locator type is wrong");
			}
			System.out.println("Element found using the value "+value);
		} catch (Exception e) {
			System.err.println("Locator not found");
		}
		return null;
	}

	public List<WebElement> findElementsBy(String type, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	public void switchToAlert() {
		// TODO Auto-generated method stub

	}

	public void acceptAlert() {
		// TODO Auto-generated method stub

	}

	public void dismissAlert() {
		// TODO Auto-generated method stub

	}

	public String getAlertText() {
		// TODO Auto-generated method stub
		return null;
	}

	public void typeAlert(String data) {
		// TODO Auto-generated method stub

	}

	public void switchToWindow(int index) {
		// TODO Auto-generated method stub

	}

	public void switchToWindow(String title) {
		// TODO Auto-generated method stub

	}

	public void switchToFrame(int index) {
		// TODO Auto-generated method stub

	}

	public void switchToFrame(WebElement ele) {
		// TODO Auto-generated method stub

	}

	public void switchToFrame(String idOrName) {
		// TODO Auto-generated method stub

	}

	public void defaultContent() {
		// TODO Auto-generated method stub

	}

	public boolean verifyUrl(String url) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyTitle(String title) {
		// TODO Auto-generated method stub
		return false;
	}

	public void close() {
		// TODO Auto-generated method stub

	}

	public void quit() {
		// TODO Auto-generated method stub

	}

}
